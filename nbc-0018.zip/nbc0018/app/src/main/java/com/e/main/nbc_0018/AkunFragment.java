package com.e.main.nbc_0018;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.e.main.nbc_0018.api.ApiClient;
import com.e.main.nbc_0018.api.ApiInterface;
import com.e.main.nbc_0018.dao.customerDao;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link AkunFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class AkunFragment extends Fragment {
    private EditText tPassword,tKode;
    private customerDao customerDao;
    private Button loginBtn;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public AkunFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment AkunFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static AkunFragment newInstance(String param1, String param2) {
        AkunFragment fragment = new AkunFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_akun, container, false);

        loginBtn = view.findViewById(R.id.loginBtn);
        tKode = view.findViewById(R.id.txtKode);
        tPassword = view.findViewById(R.id.txtPassword);
        customerDao = new customerDao();

        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                customerDao.setKode_cust(tKode.getText().toString());
                customerDao.setPassword_cust(tPassword.getText().toString());
                ApiInterface apiService = ApiClient.getClient().create(ApiInterface.class);
                Call<customerDao> apiServiceUser = apiService.login(customerDao);
                apiServiceUser.enqueue(new Callback<customerDao>() {
                    @Override
                    public void onResponse(Call<customerDao> call, Response<customerDao> response) {
                        if (response.body()!=null){
                            customerDao = response.body();
                            SharedPreferences sharedPref = getActivity().getPreferences(Context.MODE_PRIVATE);
                            SharedPreferences.Editor editor = sharedPref.edit();
                            editor.putString("kode_cust", customerDao.getKode_cust());
                            editor.apply();
                            Navigation.findNavController(view).navigate(R.id.action_akunFragment_to_userProfilFragment);
                        }else{
                            Toast.makeText(getActivity(),"Sukses",Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<customerDao> call, Throwable t) {
                        tKode.setText("");
                        tPassword.setText("");
                        Toast.makeText(getContext(), "Login Gagal", Toast.LENGTH_SHORT).show();
                    }
                });


            }
        });

        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        SharedPreferences sharedPref = getActivity().getPreferences(Context.MODE_PRIVATE);
        if(sharedPref.contains("kode_cust")){
            Navigation.findNavController(view).navigate(R.id.action_akunFragment_to_userProfilFragment);
        }
    }
}